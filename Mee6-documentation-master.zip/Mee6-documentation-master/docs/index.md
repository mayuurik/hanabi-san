# Mee6 documentation

### Some handy links

* [Our discord server](https://discord.gg/mee6)
* [Mee6 somewhat older Github page](https://github.com/cookkkie/mee6)
* [Mee6 newer Github page](https://github.com/mee6)
* [the dashboard](http://mee6.xyz/servers) this is where you configure Mee6.
* [realtime statistics](https://p.datadoghq.com/sb/b5ae28d32-9ae9580a52?tv_mode=true) for the nerds ;-)

## Star Features

|Feature|description|
|-------|-----------|
|Levels|Let your members gain **XP** and **levels** by participating in the chat!|
|Commands|Add and manage your **AWESOME** custom commands!|
|Animu and Mango|Search the web for your favorite animes and mangas.|

> AND MUCH MORE

## Who made this?

| | |
|--|--|
|![pics/cookie.jpg](pics/cookie.jpg)|Hi, I'm **Cookie**. I made the first version of Mee6 bot in 3 days.|
|![pics/vai.jpg](pics/vai.jpg)|This is **vʌı**. He corrects all the silly english related mistakes that I make on the website and on the bot.|
|![pics/sans.jpg](pics/sans.jpg)|This is **sans**. He loves archlinux and he made the Git Repo plugin.|
