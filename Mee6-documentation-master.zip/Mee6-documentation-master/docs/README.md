# Mee6 documentation
 
if you want to contribute:
* the .md files are in the 'docs' folder
* if you add a new page then also add the refrence in `mkdocs.yml`
* we are working on a template, if it already exist then please use it
